from email.mime import image
import torch
from torch import nn
from typing import Tuple, List

"""
Possible improvements:
- Batchnorm after each conv-layer
- Lr
- LeakyReLU as two first in each layer instead of normal ReLU

Should I change anchor boxes and mean/std?
"""


class _FirstLayer(nn.Sequential):
    def __init__(self, in_channels, middle_channels=[32, 64, 64], out_channels=128, kernel_size=3, stride=1, padding=1):
        super().__init__(
            nn.Conv2d(in_channels=in_channels, stride=stride, padding=padding, out_channels=middle_channels[0], kernel_size=kernel_size),
            nn.BatchNorm2d(middle_channels[0]),
            nn.MaxPool2d(stride=2, kernel_size=2),
            nn.ReLU(),
            nn.Conv2d(in_channels=middle_channels[0], stride=stride, padding=padding, out_channels=middle_channels[1], kernel_size=kernel_size),
            nn.BatchNorm2d(middle_channels[1]),
            nn.MaxPool2d(stride=2, kernel_size=2),
            nn.ReLU(),
            nn.Conv2d(in_channels=middle_channels[1], stride=stride, padding=padding, out_channels=middle_channels[2], kernel_size=kernel_size),
            nn.BatchNorm2d(middle_channels[2]),
            nn.ReLU(),
            nn.Conv2d(in_channels=middle_channels[2], stride=2, padding=padding, out_channels=out_channels, kernel_size=kernel_size),
            nn.BatchNorm2d(out_channels),
        )


class _X2ReLUConv2d(nn.Sequential):
    def __init__(self, in_channels, middle_channels, out_channels, kernel_size=3, stride_one=1, stride_two=2, padding_one=1, padding_two=1):
        super().__init__(
            nn.ReLU(),
            nn.Conv2d(in_channels=in_channels, stride=stride_one, padding=padding_one, out_channels=middle_channels, kernel_size=kernel_size),
            nn.BatchNorm2d(middle_channels),
            nn.ReLU(),
            nn.Conv2d(in_channels=middle_channels, stride=stride_two, padding=padding_two, out_channels=out_channels, kernel_size=kernel_size),
            nn.BatchNorm2d(out_channels),
        )


class ImprovedModel(torch.nn.Module):
    """
    This is a basic backbone for SSD.
    The feature extractor outputs a list of 6 feature maps, with the sizes:
    [shape(-1, output_channels[0], 38, 38),
     shape(-1, output_channels[1], 19, 19),
     shape(-1, output_channels[2], 10, 10),
     shape(-1, output_channels[3], 5, 5),
     shape(-1, output_channels[3], 3, 3),
     shape(-1, output_channels[4], 1, 1)]
    """

    def __init__(self,
                 output_channels: List[int],
                 image_channels: int,
                 output_feature_sizes: List[Tuple[int]]):
        super().__init__()
        self.out_channels = output_channels
        self.image_channels = image_channels
        self.output_feature_shape = output_feature_sizes

        self.layer_1 = _FirstLayer(in_channels=image_channels, middle_channels=[32, 64, 64], out_channels=self.out_channels[0])
        self.layer_2 = _X2ReLUConv2d(in_channels=self.out_channels[0], middle_channels=256, out_channels=self.out_channels[1])
        self.layer_3 = _X2ReLUConv2d(in_channels=self.out_channels[1], middle_channels=256, out_channels=self.out_channels[2])
        self.layer_4 = _X2ReLUConv2d(in_channels=self.out_channels[2], middle_channels=128, out_channels=self.out_channels[3])
        self.layer_5 = _X2ReLUConv2d(in_channels=self.out_channels[3], middle_channels=128, out_channels=self.out_channels[4])
        self.layer_6 = _X2ReLUConv2d(in_channels=self.out_channels[4], middle_channels=256, out_channels=self.out_channels[5], padding_two=0)

    def forward(self, x):
        """
        The forward function should output features with shape:
            [shape(-1, output_channels[0], 38, 38),
            shape(-1, output_channels[1], 19, 19),
            shape(-1, output_channels[2], 10, 10),
            shape(-1, output_channels[3], 5, 5),
            shape(-1, output_channels[3], 3, 3),
            shape(-1, output_channels[4], 1, 1)]
        We have added assertion tests to check this, iteration through out_features,
        where out_features[0] should have the shape:
            shape(-1, output_channels[0], 38, 38),
        """
        out_features = []
        out = x

        out = self.layer_1(out)
        out_features.append(out)

        out = self.layer_2(out)
        out_features.append(out)

        out = self.layer_3(out)
        out_features.append(out)

        out = self.layer_4(out)
        out_features.append(out)

        out = self.layer_5(out)
        out_features.append(out)

        out = self.layer_6(out)
        out_features.append(out)

        for idx, feature in enumerate(out_features):
            w, h = self.output_feature_shape[idx]
            out_channel = self.out_channels[idx]
            expected_shape = (out_channel, h, w)
            assert feature.shape[1:] == expected_shape, f"Expected shape: {expected_shape}, got: {feature.shape[1:]} at output IDX: {idx}"
        return tuple(out_features)
